
Instructions to install:

1. Copy 'LogicServices' folder to <your_server> path: 	
	'c:\Program Files (x86)\ClickSoftware\Service Optimization\Web\IntegrationServices'

2. Launch your Chrome browser (only works on Chrome browser) and navigate to:
	http://<your_server>/SO/IntegrationServices/LogicServices/LogicServices.html
